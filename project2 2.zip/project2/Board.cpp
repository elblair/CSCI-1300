#include "Board.h"

Board::Board() {
    resetBoard();
}

void Board::resetBoard() {
    const int COLOR_COUNT = 3;
    const string COLORS[COLOR_COUNT] = {MAGENTA, GREEN, BLUE};
    Tile new_tile;
    string current_color;
    for (int i = 0; i < _BOARD_SIZE - 1; i++) {
        current_color = COLORS[i % COLOR_COUNT];
        // new_tile = {current_color, "regular tile"};
        new_tile.color = current_color;
        new_tile.tile_type = "regular tile";
        _tiles[i] = new_tile;
    }
    new_tile.color = ORANGE;
    new_tile.tile_type = "regular tile";
    _tiles[_BOARD_SIZE - 1] = new_tile;

    _candy_store_count = 0;
    for (int i = 0; i < _MAX_CANDY_STORE; i++) {
        _candy_store_position[i] = -1;
    }

    _player_position = 0;
}

void Board::displayTile(int position) {
    if (position < 0 || position >= _BOARD_SIZE) {
        return;
    }
    Tile target = _tiles[position];
    cout << target.color << " ";
    if (position == _player_position) {
        cout << "1";
    }
    else {
        cout << " ";
    }
    cout << " " << RESET;
}

void Board::displayBoard() {
    // First horizontal segment
    for (int i = 0; i <= 23; i++) {
        displayTile(i);
    }
    cout << endl;
    // First vertical segment
    for (int i = 24; i <= 28; i++) {
        for (int j = 0; j < 23; j++) {
            cout << "   ";
        }
        displayTile(i);
        cout << endl;
    }
    // Second horizontal segment
    for (int i = 52; i > 28; i--) {
        displayTile(i);
    }
    cout << endl;
    // Second vertical segment
    for (int i = 53; i <= 57; i++) {
        displayTile(i);
        for (int j = 0; j < 23; j++) {
            cout << "   ";
        }
        cout << endl;
    }
    // Third horizontal segment
    for (int i = 58; i < _BOARD_SIZE; i++) {
        displayTile(i);
    }
    cout << ORANGE << "Castle" << RESET << endl;
}

bool Board::setPlayerPosition(int new_position) {
    if (new_position >= 0 && new_position < _BOARD_SIZE) {
        _player_position = new_position;
        return true;
    }
    return false;
}

int Board::getBoardSize() const {
    return _BOARD_SIZE;
}

int Board::getCandyStoreCount() const {
    return _candy_store_count;
}

int Board::getPlayerPosition() const {
    return _player_position;
}

bool Board::addCandyStore(int position) {
    if (_candy_store_count >= _MAX_CANDY_STORE)
    {
        return false;
    }
    _candy_store_position[_candy_store_count] = position;
    _candy_store_count++;
    return true;
}

bool Board::isPositionCandyStore(int board_position) {
    for (int i = 0; i < _candy_store_count; i++)
    {
        if(_candy_store_position[i] == board_position)
        {
            return true;
        }
    }
    return false;
}

bool Board::movePlayer(int tile_to_move_forward) { //tile_to_move_forward is the type of the card drawn 
    int new_player_position = tile_to_move_forward + _player_position;
    if(new_player_position < 0 || new_player_position >= _BOARD_SIZE)
    {
        return false;
    }
    _player_position = new_player_position;
    return true;

}

/*
void Board::isSpecialTile(int _player_position, Board &board, Card &cardDeck, ) {
    cout << "You have landed on a special tile!" << endl;
    int randomTile = rand() % 4 + 1;
    //if randomTile is 1, player gets to leap forward 4 tiles (shortcut tile) 
    if (randomTile == 1) {
        cout << "Yay! You get to move forward 4 places!" << endl;
        board.movePlayer(4);
        //update player position
    }
    //if 2, player gets to draw another card (ice cream shop tile)
    else if (randomTile == 2) {
        cout << "Congradulations! You get a chance to draw another card!" << endl;

    }
    //if 3, player gets moved back 4 spaces (gumdrop forrest tile)
    else if (randomTile == 3) {
        cout << "Yikes! You move back 4 places and lose " << << "gold." << endl;
    }
    //if 4, player gets moved back to their previous position and loses an immunity candy if they have one 
    else {
        //for loop through players candy in their inventory
            //if one of their candies is of type immunity
                //remove this candy from their inventory by calling removeCandy()
                //cout << "Uh oh! You have lost your immunity!" << endl;
            //if (no candies are type immunity) 
                //cout << "You have no immunity candy to lose, lucky you!" << endl;
        //board.setPlayerPosition()
        cout << "Oops, you get moved back to your previous spot!" << endl;

    }

}
*/