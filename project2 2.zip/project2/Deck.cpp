#include "Deck.h"
#define RED "\033[;41m"     /* Red */
#define GREEN "\033[;42m"   /* Green */
#define BLUE "\033[;44m"    /* Blue */
#define MAGENTA "\033[;45m" /* Magenta */
#define CYAN "\033[;46m"    /* Cyan */
#define ORANGE "\033[48;2;230;115;0m"  /* Orange (230,115,0)*/

Deck::Deck() {
    string color;
    int type; 
    Card card;
    for (int i = 0; i < DECK_SIZE; i++) {
        if (i < (DECK_SIZE/3)) {
            card.color = MAGENTA;
            card.type = 1;
            if (i % 4 == 0) {
                card.type = 2;
            }
        }
        else if (i > (DECK_SIZE/3) and i < 2*(DECK_SIZE/4)) {
            card.color = GREEN;
            card.type = 1;
            if (i % 4 == 0) {
                card.type = 2;
            }
        }
        else if (i > 2*(DECK_SIZE/4)) {
            card.color = BLUE;
            card.type = 1;
            if (i % 4 == 0) {
                card.type = 2;
            }
        }

        cardDeck[i] = card;
    }

}

Card Deck::drawCard() {
    // Use current time as seed for random generator 
    srand(time(0)); 
    //get random index 1-12 
    int index = rand() % DECK_SIZE;
    //return card from index of structs
    return cardDeck[index];
}
