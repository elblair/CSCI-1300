#ifndef DECK_H
#define DECK_H
#include <iostream>
#include <vector>
#define RED "\033[;41m"     /* Red */
#define GREEN "\033[;42m"   /* Green */
#define BLUE "\033[;44m"    /* Blue */
#define MAGENTA "\033[;45m" /* Magenta */
#define CYAN "\033[;46m"    /* Cyan */
#define ORANGE "\033[48;2;230;115;0m"  /* Orange (230,115,0)*/

using namespace std; 

struct Card {
    string color;
    int type;

    Card() {
        color = "";
        type = 0;
    }
    
    Card(string c, int t) {
        color = c;
        type = t;
    }
};

class Deck {
    private: 
    const static int DECK_SIZE = 12;
    Card cardDeck[DECK_SIZE];
    
    public:
    Card drawCard();
    Deck();
};
#endif