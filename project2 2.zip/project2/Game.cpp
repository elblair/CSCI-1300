#include "Game.h"
#include "Board.h"
#include "candyStore.h"
#include "Deck.h"
#include "Player.h"
#include <iostream>
#include <vector>
#include <string>
#include <fstream>
#include <sstream> 
#include <ctime>


//constructors 
Game::Game() {
    vector<Character> characters;
    vector<Candy> candies;
    readInCandies();
    readInCharacters();
    readInRiddles();
}

//main run of the game, called from driver
void Game::runGame() {
    //get number of players and player names
    cout << "Welcome to candyland! Please enter the number of participants:" << endl;
    cin >> numOfPlayers;
    string player1Name;
    Character player1;
    Character player2;
    string player2Name;
    cout << "Enter player name:" << endl;
    cin >> player1Name;
    cout << "Awesome! Here is a list of characters a player can select from:" << endl;
    //initialize player 
    player1 = initializePlayer(player1Name);
    //ask player1 if they want to visit candy store
    char choice;
    char choice2;
    cout << "Do you want to visit the candy store?(y/n)" << endl;
    cin >> choice;
    //if y, visit candy store
    if (choice == 'y') {
        //cout << "hello" << endl;
        visitCandyStore(player1Name, activeCharacters, player1, candyStore);
        //cout << "bob" << endl;
    }
    //if n, move to player 2
    cout << "Enter the name of Player 2:" << endl;
    cin >> player2Name;
    cout << "Awesome! Here is a list of characters a player can select from:" << endl;
    //initialize player 2
    player2 = initializePlayer(player2Name);
    //ask player1 if they want to visit candy store
    cout << "Do you want to visit the candy store?(y/n)" << endl;
    cin >> choice2;
    if (choice2 == 'y') {
        visitCandyStore(player2Name, activeCharacters, player2, candyStore);
    }
    //call main menu function to begin playing the game
    mainMenu(player1Name, player1);
    mainMenu(player2Name, player2);

}

void Game::displayCharacterMenu() {
    //print character menu
    for (int i = 0; i < characters.size(); i++) {
        if (characters.at(i).pName == "") {
            cout << "Name: " << characters.at(i).cName << endl;
            cout << "Stamina: " << characters.at(i).stamina << endl;
            cout << "Gold: " << characters.at(i).gold << endl;
            for (int j = 0; j < characters[i].candy_amount; j++) {
                cout << "[" << characters[i].candies[j].name << "]" << "     ";
                if (j % 3 == 2) {
                    cout << endl;
                }
            }
            cout << endl;
            cout << "--------------------------------------------------------------------------------------------" << endl; 
        }
    }
}

Character Game::initializePlayer(string playerName) {
    string characterName;
    Character playa;
    displayCharacterMenu();
    cout << "The selected character is" << endl;
    cin >> characterName;
    //loop through vector of character structures
    for (int i = 0; i < characters.size(); i++) {
        //find chosen character and set pName to playerName
        if (characters.at(i).cName == characterName) {
            characters.at(i).pName = playerName;
            for (int j = 0; j < numOfPlayers; j++) {
                if (activeCharacters[j].cName == "") {
                    activeCharacters[j] = characters.at(i);
                    playa = activeCharacters[j];
                }
            }
        }
    }
    //return character struct 
    return playa;
}


void Game::visitCandyStore(string playerName, Character activeCharacters[], Character characterInPlay, CandyStore candyStore) {
    //for (each active player)
    Candy candyToSwitchStruct;
    Candy candyToBuyStruct;
    string candyToBuy;
    string candyToSwitch;
    int newGold;
    //cout << "hello" << endl;
    cout << "Here is a list of candies in the store: " << endl;
    candyStore.displayCandies(candiesFromFile);
    //cout << "hi" << endl;
    /*
    for (int i = 0; i < numOfPlayers; i++) {
        if (activeCharacters[i].pName == playerName) {
            candyStore.displayCandies(candiesFromFile);
            //int index = canBuyCandy(activeCharacters[i]);
        }
    }
    */
    //check to see if player has 0 coins
    if (characterInPlay.gold <= 0) {
        cout << "You have 0 gold coins. You cannot buy any candy" << endl;
    }
    int candyCount;
    char substituteCandy;
    //count how many candies the player has currently
    for (int i = 0; i < 9; i++) {
        if (!(characterInPlay.candies[i].name == "")) {
            candyCount++;
        }
    }
    //check if player has max candies 
    if (candyCount == 9) {
        cout << "You already have the max amount of candies. Would you like to substitute one of your candies for a different one?(y/n)" << endl;
        cin >> substituteCandy;
        //check if user input is valid 
        while (cin.fail() || (substituteCandy != 'y' && substituteCandy != 'n')) {
            cout << "Invalid input. Please try again" << endl;
            cin.clear();
            cin.ignore(10000, '\n');
            cin >> substituteCandy;
        }
        if (substituteCandy == 'y') {
            cout << "Here is your current inventory:" << endl;
            //print inventory 
            cout << "Which candy would you like to substitute?" << endl;
            cin.clear();
            cin.ignore(10000, '\n');
            getline(cin, candyToSwitch);
            //find candy that they want to substitute and set it to the new candy that they want 
            for (int j = 0; j < candyCount; j++) {
                if (characterInPlay.candies[j].name == candyToSwitch) {
                    //set index to empty 
                    characterInPlay.candies[j].name = "";
                    cout << "What candy would you like to replace it with?" << endl;
                    cin >> candyToBuy;
                    characterInPlay.candies[j].name = candyToBuy;
                }
            }
            //change gold 
            for (int i = 0; i < 11; i++) {
                if(candyToSwitch == candiesFromFile[i].name) {
                    candyToSwitchStruct = candiesFromFile[i]; 
                }
                if(candyToBuy == candiesFromFile[i].name) {
                    candyToBuyStruct = candiesFromFile[i]; 
                }
            }
            //remove candy from store
            //candyStore.removeCandy(candyToBuyStruct);
            //add candy that was swaped out back to store
            //candyStore.addCandy(candyToSwitchStruct);
            newGold = characterInPlay.gold - candyToBuyStruct.price;
            newGold = characterInPlay.gold + candyToSwitchStruct.price;
            // cout << "Here is your new inventory:" << endl;
            // displayPlayerStats(characterInPlay);
        }
        else if (characterInPlay.gold - candyToBuyStruct.price < 0) {
            cout << "You don't have enough gold to purchase this candy" << endl;
        }
        else {
            cout << "Which candy do you want to buy?" << endl;
            cin.clear();
            cin.ignore(10000, '\n');
            //getline because multiple strings 
            string candyToBuy;
            getline(cin, candyToBuy);
            //loop through current candies + 1 to find next empty index and set that index to the candy that the user wants to buy 
            for (int k = 0; k < candyCount + 1; k++) {
                if (characterInPlay.candies[k].name == "") {
                    characterInPlay.candies[k] = candyToBuyStruct;
                }
            }
            candyCount++;
        }
        //addCandy(candyToBuyStruct, characterInPlay, candyCount);
        //removeCandy()
        cout << "Here is your new inventory:" << endl;
        displayPlayerStats(characterInPlay, candyCount);
    }
    else {
            //cout << "help me pls" << endl;
            cout << "Which candy do you want to buy?" << endl;
            cin.clear();
            cin.ignore(10000, '\n');
            //getline because multiple strings 
            string candyToBuy;
            //cout << "hi hi" << endl;
            getline(cin, candyToBuy);
            //cout << "This code broken as hell" << endl;
            //loop through current candies + 1 to find next empty index and set that index to the candy that the user wants to buy 
            for (int k = 0; k < candyCount; k++) {
                if (characterInPlay.candies[k].name == "") {
                    cout << "merp" << endl;
                    characterInPlay.candies[k] = candyToBuyStruct;
                    candyCount++;
                }
            }
            //candyCount++;
            //addCandy(candyToBuyStruct, characterInPlay, candyCount);
            //cout << "blahblahblah" << endl;
            cout << "Awesome! This candy will be added to your inventory!" << endl;
            cout << "Here is your new inventory:" << endl;
            displayPlayerStats(characterInPlay, candyCount);
    }
}

/*
bool Game::addCandy(Candy candy, Character characterInPlay, int candyCount) {
    if (candyCount == 9) {
        return false;
    }
    else {
        for (int i = 0; i < 9; i++) {
            if (characterInPlay.candies[i].name.empty()) {
                characterInPlay.candies[i] = candy;
                candyCount++;
                return true;
            }
        }
    }
    return false;
}

bool Game::removeCandy(string candyName) {
    for (int i = 0; i < candyName.length(); i++) {
        candyName[i] = tolower()
    }
}
*/

// Function to write player stats to a file
void writePlayerStatsToFile(Character characterInPlay) {
    // Open the file in output mode
    string fileName = "newFile";
    ofstream outputFile(fileName);

    // Check if the file is opened successfully
    if (!outputFile.is_open()) {
        cout << "Error opening file for writing: " << fileName << endl;
        return;
    }

    // Write player stats to the file
    outputFile << "Player Name: " << characterInPlay.pName << endl;
    outputFile << "Character Name: " << characterInPlay.cName << endl;
    outputFile << "Stamina: " << characterInPlay.stamina << endl;
    outputFile << "Gold: " << characterInPlay.gold << endl;
    outputFile << "Candies: " << endl;
    for (int i = 0; i < characterInPlay.candy_amount; ++i) {
        //outputFile << "  - " << characterInPlay.candies[i].candyName << ": " << characterInPlay.candies[i].candyAmount << "\n";
    }

    // Close the file
    outputFile.close();

    cout << "Player stats written to file: " << fileName << endl;
}



void handleCalamity(bool hasMagicalCandy, Character characterInPlay) {
    // Seed for random number generation
    srand(time(0));

    // Generate a random number (0 to 99) to determine the type of calamity
    int calamityChance = rand() % 100;

    // Calamity: Candy Bandits (30% Chance)
    if (calamityChance < 30) {
        int stolenGold = rand() % 10 + 1;  // Random gold loss between 1 and 10
        characterInPlay.gold -= stolenGold;
        if (characterInPlay.gold < 0) {
            characterInPlay.gold = 0;
        }
        cout << "Oh no! Candy Bandits have swiped " << stolenGold << " gold coins!" << endl;
    }
    // Calamity: Lost in a Lollipop Labyrinth (35% Chance)
    else if (calamityChance < 65) {
        cout << "Oh dear! You got lost in the lollipop labyrinth!" << endl;
        // Player has a chance to recover by playing Rock, Paper, Scissors (not implemented here)
    }
    // Calamity: Candy Avalanche (15% Chance)
    else if (calamityChance < 80) {
        int lostStamina = std::rand() % 6 + 5;  // Random stamina loss between 5 and 10
        characterInPlay.stamina -= lostStamina;
        if (characterInPlay.stamina < 0) {
            characterInPlay.stamina = 0;
        }
        cout << "Watch out! A candy avalanche has struck! Lost " << lostStamina << " stamina." << endl;
        // Player has a chance to recover by playing Rock, Paper, Scissors (not implemented here)
    }
    // Calamity: Sticky Taffy Trap (20% Chance)
    else {
        cout << "Oops! You are stuck in a sticky taffy trap!\n";
        // Check if the player has a Magical Candy to escape the trap
        if (hasMagicalCandy) {
            cout << "But you have a Magical Candy! Use it to escape the sticky trap." << endl;
            // Player uses the Magical Candy and can continue the turn
            hasMagicalCandy = false;
        } else {
            cout << "Unfortunately, you don't have a Magical Candy. You are immobilized for the next turn." << endl;
            // Player is immobilized for the next turn
        }
    }
}



/*
int movePlayer(Card &cardDeck, Board &board, Character &player, int playerPosition) {
    //loop through the tiles after the tile the player is on and find next tile that matches card drawn 
    for (int i = playerPosition + 1; i < _BOARD_SIZE; i++) {
        if ()
    }
}
*/

void Game::displayPlayerStats(Character characterInPlay, int candyCount) {
    cout << "Here are your stats:" << endl;
    cout << "Player name: " << characterInPlay.pName << endl;
    cout << "Character: " << characterInPlay.cName << endl;
    cout << "Stamina:" << characterInPlay.stamina << endl;
    cout << "Gold: " << characterInPlay.gold << endl;
    cout << "Candies: " << endl;
    //cout << 
    for (int i = 0; i < candyCount; i++) {
        cout << "[" << characterInPlay.candies[i].name << "]" << "     ";
        if (i % 3 == 2) {
            cout << endl;
        }
    }
    cout << "-----------------------------------------" << endl;
}


void Game::mainMenu(string playerName, Character characterInPlay) {
    //if (playerName == activeCharacters[i].pName) {}
    //count how many candies the player has currently
    int candyCount = 0;
    for (int i = 0; i < 9; i++) {
        if (!(characterInPlay.candies[i].name == "")) {
            candyCount++;
        }
    }
    cout << "Let's begin the game. Here is the board:" << endl;
    board.displayBoard();
    cout << "It's " << playerName << " turn" << endl;
    cout << "Please select a menu option:" << endl;
    cout << "1. Draw a card" << endl;
    cout << "2. Use candy" << endl;
    cout << "3. Show player stats" << endl;
    int mainMenuChoice;
    cin >> mainMenuChoice;
    if (mainMenuChoice == 1) {
        cout << "To draw a card press D" << endl;
        char playerDrawsCard;
        cin >> playerDrawsCard;
        if (playerDrawsCard != 'D') {
            cout << "Invalid input. Please try again." << endl;
            cin >> playerDrawsCard;
        }
        Card cardDrawn = deckOfCards.drawCard();
        if (cardDrawn.color == MAGENTA) {
            cout << "You drew a Pretty Pink card. Your game piece advances to Pink tile. Here's the updated trail:" << endl;
            //movePlayer(cardAmount);
            board.displayBoard();

        }
        else if (cardDrawn.color == GREEN) {
            cout << "You drew a Gorgelicious Green card. Your game piece advances to Green tile. Here's the updated trail:" << endl;
            //movePlayer(cardAmount);
            //board.addCandyStore();
            board.displayBoard();
        }
        else {
            cout << "You drew a Beautiful Blue card. Your game piece advances to Blue tile. Here's the updated trail:" << endl;
            int cardAmount = cardDrawn.type;
            //movePlayer(cardAmount);
            board.displayBoard();
        }
    }
    else if (mainMenuChoice == 2) {
        cout << "Here is a list of your candies:" << endl;
        //for (int i = 0; i < )
    }
    else if (mainMenuChoice == 3) {
        cout << "idfk" << endl;
        displayPlayerStats(characterInPlay, candyCount);
    }
    else {
        cout << "Invalid choice. Please try again." << endl;

    }
}

bool secondPlayerHasShield() {
    // Seed for random number generation
    srand(time(0));

    // Generate a random number (0 or 1) to determine if the shield is present
    int randomNumber = rand() % 2;

    // If the random number is 1, the second player has a shield; otherwise, they don't
    return randomNumber == 1;
}

void handleSameTileRobbery(bool secondPlayerHasShield, Character characterInPlay) {
    // Seed for random number generation
    srand(time(0));

    // Determine the amount to steal (random between 5 and 30)
    int amountToSteal = rand() % 26 + 5;

    // Check if the second player has a shield
    if (secondPlayerHasShield) {
        // If the second player has a shield, move the first player back by one tile
        cout << "Second player has a shield! First player moved back by one tile." << endl;
    } 
    else {
        // If no shield, steal gold from the second player
        cout << "First player steals " << amountToSteal << " gold from the second player." << endl;
        characterInPlay.gold -= amountToSteal;

        // Ensure the second player's gold doesn't go below zero
        if (characterInPlay.gold < 0) {
            characterInPlay.gold = 0;
        }
    }
}


void Game::readInCandies() {
    //vector<Candy> candies;
    string fileName = "candies.txt";
    ifstream file;
    file.open(fileName); //open candy file
    string line; 
    //Candy candy;

    if(!file.is_open()) {
        cout << "Error opening candy file." << endl;
        //return -1;
    }

    while(getline(file, line)) {
        stringstream ss(line);
        //string name, description, effectType, effectValue, candyType, price;
        //int effectValueInt, priceInt;
        string effectValue, price;
        Candy candy;
        //read in data from file and set it to candy struct
        getline(ss, candy.name, '|');
        if(candy.name == "Name") {
            continue;
        }
        getline(ss, candy.description, '|');
        getline(ss, candy.effectType, '|');
        getline(ss, effectValue, '|'); //can't place directly into struct because it reads as a string
        //cout << effectValue << endl;
        candy.effectValue = stoi(effectValue); //convert string to int and place into Candy struct
        getline (ss, candy.candyType, '|');
        getline (ss, price); 
        //cout << price << endl;
        candy.price = stoi(price);
        //Candy candy = {name, description, effectType, effectValue, candyType, price};
        candiesFromFile.push_back(candy);
    }
    //cout << candiesFromFile.size();
    file.close();
    //return candies;
}

//read in characters from file and populate character vector
void Game::readInCharacters() {
    string fileName = "characters.txt";
    ifstream file;
    file.open(fileName); //open character file
    string line; 
    string candy;
    Candy characterCandyStruct;
    string stamina, gold, characterCandy;

    if(!file.is_open()) {
        cout << "Error opening character file." << endl;
        //return -1;
    }
    getline(file, line);
    while(getline(file, line)) {
        stringstream ss(line);
        //string candies[9]; //may not need to initialize 
        Character character;
        character.pName = "";
        //read in data from file and set it to  struct
        getline(ss, character.cName, '|');
        //check if its the header of the file
        // if(player.cName == "character name") {
        //     continue;
        // }
        getline(ss, stamina, '|'); //can't place directly into struct because it reads as a string
        character.stamina = stoi(stamina); //convert string to int and place into struct
        getline(ss, gold, '|');
        character.gold = stoi(gold);
        getline(ss, characterCandy); 
        stringstream characterCandies(characterCandy); //create 
        while(getline(characterCandies, candy, ',')) {
            // cout << "candy" << candy << endl;
            //initialzie each index of candy array to candy read in from file
            for (int i = 0; i < 11; i++) {
                if(candy == candiesFromFile[i].name) {
                    characterCandyStruct = candiesFromFile[i];
                    //cout << characterCandyStruct.name << endl; 
                }
                
            }
            
            if(character.candy_amount < 9) {
                character.candy_amount++;
                character.candies[character.candy_amount - 1] = characterCandyStruct;
            } 
        }
        //cout <<"character.candy_amount " << character.candy_amount;
        
        //player.candies = candies;
        characters.push_back(character);

        // reset character to empty struct 

        for(int i = 0; i < character.candy_amount; i++) {
            character.candies[i].name = "";
            character.candies[i].description = "";
            character.candies[i].effectType = "";
            character.candies[i].effectValue = 0;
            character.candies[i].candyType = "";
            character.candies[i].price = 0;
        }
        character.candy_amount = 0;
        
    }
    file.close();
    //return characters;
}


void Game::readInRiddles() {
    vector<Riddle> riddlesFromFile;
    string fileName = "riddles.txt";
    ifstream file;
    file.open(fileName); //open riddles file
    string line; 

    if(!file.is_open()) {
        cout << "Error opening riddles file." << endl;
        //return -1;
    }
    string question, answer;
    while(getline(file, line)) {
        stringstream ss(line);
        Riddle riddle;
        getline(ss, riddle.question, '|');
        getline(ss, riddle.answer);
        riddlesFromFile.push_back(riddle);
    }
    file.close();
}

/*
int movePlayer(Card &cardDeck, Board &board, Character &player, int playerPosition) {
    //loop through the tiles after the tile the player is on and find next tile that matches card drawn 
    for (int i = playerPosition + 1; i < _BOARD_SIZE; i++) {
        if ()
    }
}


bool Game::riddles(char choice, Board &board) {

}
    
bool Game::rockPaperScissors(activeCharacters[]) {

}
    
void Game::hiddenTreasure(bool, Charcter &player) {

}
    
void Game::useCandy(Board &board, Candy candyUsed, Chacter &player, activeCharacters) {

}
*/
