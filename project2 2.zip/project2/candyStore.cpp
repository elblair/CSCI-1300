#include "Board.h"
#include "candyStore.h"

CandyStore::CandyStore() {
    store_name = "";
    candy_count = 0;
}

CandyStore::CandyStore(string _store_name) {
    store_name = _store_name;
    candy_count = 0;
}

bool CandyStore::addCandy(Candy candy) {
    if (candy_count == _MAX_CANDIES) {
        cout << "Store has max candies. Unable to add more." << endl;
        return false;
    }
    _candies[candy_count] = candy;
    candy_count++;
    return true;
}

bool CandyStore::removeCandy(string _candy_name) {
    bool removedCandy = false;
    for (int i = 0; i < candy_count; i++) {
        if (_candies[i].name == _candy_name) {
            for (int j = i + 1; j < candy_count - 1; j++) {
                _candies[j-1] = _candies[j];
            }
            candy_count--;
            removedCandy = true;
            break;
        }
    }
    return removedCandy;
}

void CandyStore::displayCandies(vector<Candy> candies){
    // if (candy_count == 0) {
    //     cout << "No candies are present in this candy store" << endl;
    // }
    srand(time(0));
    //loop three times to generate a random index in candies vector
    //cout << "Welcome to the candy store! Here is a list of candies available:" << endl;
    for (int i = 0; i < 3; i++) {
        int rCandy = rand() % candies.size();
        //find way to make sure the store does generate two of the same candies
        //if ()
        if (i != 0) {
            cout << "----------------------------" << endl;
        }
        //print out candy at index that is generated 
        cout << "Name: " << candies.at(rCandy).name << endl;
        cout << "Description: " << candies.at(rCandy).description << endl;
        cout << "Effect type: " << candies.at(rCandy).effectType << endl;
        cout << "Effect value: " << candies.at(rCandy).effectValue << endl;
        cout << "Price: " << candies.at(rCandy).price << endl;
    }
    //cout << "hi" << endl;
}

