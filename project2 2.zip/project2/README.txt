------------------------
HOW TO COMPILE AND RUN
------------------------
Compile: g++ Board.cpp Game.cpp candyStore.cpp Deck.cpp gameDriver.cpp
Run: ./a.out

------------------------
DEPENDENCIES
------------------------
Player.h, Board.h, Game.h, and Deck.h, candyStore.h, must be in the same directory as the cpp files in order to compile.

------------------------
SUBMISSION INFORMATION
------------------------
CSCI1300 Fall 2023 Project 2
Author: El Blair
Recitation: 605 - Vrinda Sheena Anil 
Date: Dec 7, 2023

------------------------
ABOUT THIS PROJECT
------------------------
This project runs a game similar to the old fashioned board game CandyLand, but has a few differences.