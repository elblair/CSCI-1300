#ifndef PLAYER_H
#define PLAYER_H
#include <iostream>
#include <vector>

using namespace std; 

class Player {
    private: 
    string playerName;
    string characterName;
    int stamina;
    int gold;
    int playerPosition;
    
    public:
    string getPName() const;
    void setPName(string name);
    string getCName() const;
    void setCName(string name);
    int getStamina() const;
    void setStamina(int _stamina);
    int getGold() const;
    void setGold(int _gold);
    int getPlayerPosition() const;
    void setPlayerPosition(int position);
    

};
#endif