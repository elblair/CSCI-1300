#include "Player.h"

Player::Player() {
    playerName = "";
    characterName = "";
    stamina = 0;
    gold = 0;
    playerPosition = 0;
}

Player::Player(string pName, string cName, int _stamina, int _gold, int pos) {
    playerName = pName;
    characterName = cName;
    stamina = _stamina;
    gold = _gold;
    playerPosition = pos;
}

string Player::getPName() const {
    return playerName;
}

void Player::setPName(string pName) {
    playerName = pName;
}

string Player::getCName() const {
    return characterName;
}

void Player::setCName(string cName) {
    characterName = cName;
}

int Player::getStamina() const {
    return stamina;
}
   
void Player::setStamina(int _stamina) {
    stamina = _stamina;
}
    
int Player::getGold() const {
    return gold;
}
    
void Player::setGold(int _gold) {
    gold = _gold;
}

int Player::getPlayerPosition() const {
    return playerPosition;
}

void Player::setPlayerPosition(int pos) {
    playerPosition = pos;
}