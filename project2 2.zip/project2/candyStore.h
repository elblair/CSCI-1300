#ifndef CANDYSTORE_H
#define CANDYSTORE_H
#include "Board.h"
#include <iostream>
#include <vector>
#define RED "\033[;41m"     /* Red */
#define GREEN "\033[;42m"   /* Green */
#define BLUE "\033[;44m"    /* Blue */
#define MAGENTA "\033[;45m" /* Magenta */
#define CYAN "\033[;46m"    /* Cyan */
#define ORANGE "\033[48;2;230;115;0m"  /* Orange (230,115,0)*/

#define RESET "\033[0m"

using namespace std;

struct Candy {
    string name;
    string description;
    string effectType;
    int effectValue;
    string candyType;
    int price;
};

class CandyStore {
    private:
    string store_name;
    const static int _MAX_CANDIES = 5;
    Candy _candies[_MAX_CANDIES];
    int candy_count;
    
    public:
    CandyStore();
    CandyStore(string store_name);
    bool addCandy(Candy candy);
    bool removeCandy(string candy_name);
    void displayCandies(vector<Candy> candies);
    // bool swapCandies(Candy candy, string candy_name);
};
#endif