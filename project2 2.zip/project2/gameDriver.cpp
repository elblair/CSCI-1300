#include <iostream>
#include <vector>
#include "Board.h"
#include "Game.h"
#include "candyStore.h"
#include "Deck.h"
#include "Player.h"
#define RED "\033[;41m"     /* Red */
#define GREEN "\033[;42m"   /* Green */
#define BLUE "\033[;44m"    /* Blue */
#define MAGENTA "\033[;45m" /* Magenta */
#define CYAN "\033[;46m"    /* Cyan */
#define ORANGE "\033[48;2;230;115;0m"  /* Orange (230,115,0)*/
#define RESET "\033[0m"

using namespace std;


int main() {
    Game game;
    CandyStore candyStore;
    game.runGame();
    //game.displayCharacterMenu();
    return 0;
}