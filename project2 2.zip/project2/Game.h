#ifndef GAME_H
#define GAME_H
#include "Board.h"
#include "Deck.h"
#include "candyStore.h"
#include <iostream>
#include <vector>
#include <sstream>
#include <fstream>

using namespace std;

//g++ Board.cpp Game.cpp candyStore.cpp Deck.cpp gameDriver.cpp 

struct Character {
    string pName;
    string cName;
    int stamina;
    int gold;
    //int playerPosition;
    Candy candies[9];
    int candy_amount;
};
//for each player : select candy store and visit candy store

struct Riddle {
    string question;
    string answer;
};

class Game {
    private:
    Board board;
    vector<Character> characters;
    vector<Candy> candiesFromFile;
    Character activeCharacters[2];
    Deck deckOfCards;
    CandyStore candyStore;
    int numOfPlayers;
    const static int numOfTiles;
    string candyToBuy;
    string playerName;
    string characterName;
    int stamina;
    int gold;
    int playerPosition;
    const static int MAX_CANDY = 9;

    public:
    Game();
    void runGame();
    void mainMenu(string, Character);
    
    void readInCandies();
    void readInCharacters();
    void readInRiddles();

    //void handleCalamity(bool hasMagicalCandy, Character characterInPlay);
    //

    Character initializePlayer(string);
    void visitCandyStore(string playerName, Character activeCharacters[], Character characterInPlay, CandyStore candyStore);
    void displayCharacterMenu();
    //void movePlayer();
    int canBuyCandy(Character);
    void displayPlayerStats(Character, int);
    bool addCandy(Candy);
    bool removeCandy(string);

};
#endif
